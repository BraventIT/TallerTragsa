﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVVMExampleDemo.ViewModels.Base
{
    public class ViewModelLocator
    {
        //readonly IUnityContainer _container;

        //public ViewModelLocator()
        //{
        //    _container = new UnityContainer();
        //    #region Viewmodels
        //    _container.RegisterType<MainPageViewModel>();
        //    #endregion
        //}

        //public MainPageViewModel MainPageViewModel
        //{
        //    get { return _container.Resolve<MainPageViewModel>(); }
        //}

    }
}
